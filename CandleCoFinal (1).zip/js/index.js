document.getElementById("myBtn").addEventListener("click", function() {
  alert("Hello World!");
});



